<div class="hit-the-floor">404</div>

<div class="alternative-versions absolute bottom-0 w-full flex justify-center underline space-x-4 p-12">
  <a 
     href="https://codepen.io/ThatGuySam/pen/CytDA?editors=1000"
     target="_blank"
  >🍗 Original Version</a>
  <a 
     href="https://codepen.io/ThatGuySam/pen/rNOqdqK"
     target="_blank"
  >⚖️ Scalable Version</a>
  <a 
     href="https://codepen.io/ThatGuySam/pen/eYpPMXj?editors=1000"
     target="_blank"
  >🎨 Color Version</a>
</div>